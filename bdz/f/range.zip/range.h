#ifndef RANGE_H
#define RANGE_H

#include <cmath>

class Range {
 public:
  Range() = delete;

  explicit Range(int end) : start_(0), end_(end), step_(1) {
  }

  Range(int start, int end, int step = 1) : start_(start), end_(end), step_(step) {
  }

 public:
  struct RangeIterator {
   public:
    explicit RangeIterator(int cur_num, int istep = 1) : cur_num_(cur_num), istep_(istep) {
    }

   public:
    int operator*() const {
      return cur_num_;
    }
    const int* operator->() const {
      return &cur_num_;
    }

    RangeIterator& operator++() {
      cur_num_ += istep_;
      return *this;
    }

    RangeIterator operator++(int) {
      RangeIterator tmp = *this;
      ++(*this);
      return tmp;
    }

    friend bool operator==(const RangeIterator& a, const RangeIterator& b) {
      return a.cur_num_ == b.cur_num_;
    };
    friend bool operator!=(const RangeIterator& a, const RangeIterator& b) {
      return a.cur_num_ != b.cur_num_;
    };

   private:
    int cur_num_;
    int istep_;
  };

 public:
  RangeIterator begin() const {  // NOLINT
    return RangeIterator(start_, step_);
  }

  RangeIterator end() const {  // NOLINT
    int len = end_ - start_;
    int step_count = 0;
    if (len * step_ <= 0) {
      step_count = 0;
    } else {
      step_count = len / step_ + (Module(len, step_) ? 1 : 0);
    }
    int the_end = start_ + step_ * step_count;
    return RangeIterator(the_end, step_);
  }

  RangeIterator rbegin() const {  // NOLINT
    int c = start_;
    for (int i : *this) {
      c = i;
    }
    return RangeIterator(c, -step_);
  }

  RangeIterator rend() const {  // NOLINT
    int the_rstart = start_ - step_;
    int len = end_ - start_;
    if (len * step_ <= 0) {
      the_rstart = start_;
    }
    return RangeIterator(the_rstart, -step_);
  }

 private:
  int Module(int num, int base) const {
    base = std::abs(base);
    int res = std::abs(num) % base;
    return (num >= 0 || !res) ? res : base - res;
  }

 private:
  int start_;
  int end_;
  int step_;
};

#endif