#ifndef IMATRIX_MATRIX_H
#define IMATRIX_MATRIX_H

#include <cstddef>

class Matrix {
private:    
  double* _storage;
  size_t row;
};

#endif