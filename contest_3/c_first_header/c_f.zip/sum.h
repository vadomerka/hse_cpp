#ifndef H_SUM
#define H_SUM

#include <cstdint>

int64_t Sum(int x, int y);

#endif