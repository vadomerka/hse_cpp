#include "sum.h"

int64_t Sum(int x, int y) {
  return x + y;
}
