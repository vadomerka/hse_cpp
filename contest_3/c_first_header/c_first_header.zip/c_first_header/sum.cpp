#include "sum.h"
#include <iostream>

int Sum(int x, int y) {
  return x + y;
}
