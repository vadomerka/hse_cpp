#ifndef H_SUM
#define H_SUM

int Sum(int x, int y);

#endif